import { Component } from '@angular/core';
import { SelectrolemodalComponent } from '../../selectrolemodal/selectrolemodal.component';
import { SidenavcompanyadminComponent } from '../../sidenavcompanyadmin/sidenavcompanyadmin.component';
import { MdbModalRef, MdbModalService } from 'mdb-angular-ui-kit/modal';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  modalRef: MdbModalRef<SelectrolemodalComponent> | null = null;
  modalRefsidenav: MdbModalRef<SidenavcompanyadminComponent> | null = null;
 
  constructor(private modalService: MdbModalService) {}

  openModal() {
    this.modalRef = this.modalService.open(SelectrolemodalComponent)
  }

  
  openModalSidenav() {
    this.modalRef = this.modalService.open(SidenavcompanyadminComponent,  {
      modalClass: 'modal-dialog-scrollable modal-fullscreen sidebarmodel', nonInvasive: true,
    })
  }
}
